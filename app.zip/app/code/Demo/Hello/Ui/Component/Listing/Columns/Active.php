<?php
namespace Demo\Hello\Ui\Component\Listing\Columns;
use Magento\Framework\Data\OptionSourceInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
class Active extends Column implements OptionSourceInterface {
    /** * @param ContextInterface $context * @param UiComponentFactory $uiComponentFactory * @param StatusSource $source * @param array $components * @param array $data */
    public function __construct( ContextInterface $context, UiComponentFactory $uiComponentFactory, array $components = [], array $data = [] ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }
    public function prepareDataSource(array $dataSource) {
        $dataSource = parent::prepareDataSource($dataSource);
        $options = [ 1 => __('Yes'), 2 => __('No')];

    if (empty($dataSource['data']['items'])) {
        return $dataSource;
    }

    foreach ($dataSource['data']['items'] as &$item) {
        $item['is_active'] = $options[1];
        $item['id'] = $item['entity_id'];
        $item['title'] = $item['sku'];
        $item['created_at'] = $item['created_at'];
        if (isset($options[$item['has_options']])) {
            $item['is_active'] = $options[$item['has_options']];
        }

    }
    //print_r($dataSource);exit();
    return $dataSource;
}

    public function toOptionArray()
    {
        $result = [];
        $result[] = ['value' => 1, 'label' => 'Yes'];
        $result[] = ['value' => 2, 'label' => 'No'];

        return $result;
    }


}
